"use client";
import React from "react";
import { Cart } from "./Cart";

function page() {
  return <Cart />;
}

export default page;
