import React from "react";
import Payment from "./Payment";

function page() {
  return <Payment />;
}

export default page;
