import React from "react";
import Privacy from "./Privacy";
function page() {
  return <Privacy />;
}

export default page;
