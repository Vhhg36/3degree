import React from "react";
import { ProductDetails } from "./ProductDetails";

function page() {
  return <ProductDetails />;
}

export default page;
