import React from "react";
import Product from "./Product";

function page() {
  return <Product />;
}

export default page;
