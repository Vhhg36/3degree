import React from "react";
import Terms from "./Terms";

function page() {
  return <Terms />;
}

export default page;
